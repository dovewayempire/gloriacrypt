<!doctype html>
<html class="no-js" lang="en" dir="ltr">

<!-- Mirrored from pixelwibes.com/template/ebazar/html/dist/ui-elements/auth-signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 May 2024 08:48:58 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>GloriaCrypt || Password Reset </title>
    

    <!-- project css file  -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/ebazar.style.min.css')); ?>">
</head>
<body>
    <div id="ebazar-layout" class="theme-blue">

        <!-- main body area -->
        <div class="main p-2 py-3 p-xl-5 ">

            <!-- Body: Body -->
            <div class="body d-flex p-0 p-xl-5">
                <div class="container-xxl">




                        <div class="col-lg-12 d-flex justify-content-center align-items-center border-0 rounded-lg auth-h100">
                            <div class="w-100 p-3 p-md-5 card border-0 shadow-sm" style="max-width: 32rem;">
                                <!-- Form -->
                                <form action="<?php echo e(route('admin.reset.password')); ?>" method="POST" class="row g-1 p-3 p-md-4">
                                     <?php echo csrf_field(); ?>

                                     <input type="hidden" name="token" value="<?php echo e($token); ?>">
                                    <div class="col-12 text-center mb-5">
                                        <h1>Change password</h1>

                                    </div>
                                    <div class="col-12">
                                        <div class="mb-2">
                                            <label class="form-label">Email</label>
                                            <input type="email" name="email" class="form-control form-control-lg" placeholder="">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="mb-2">
                                            <label class="form-label">Password</label>
                                            <input type="password" name="password" class="form-control form-control-lg" placeholder="*****************">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="mb-2">
                                            <label class="form-label">Retype Paasword</label>
                                            <input type="password_confirmation" name="password_confirmation" class="form-control form-control-lg" placeholder="************">
                                        </div>
                                    </div>

                                    <div class="row">

                                        <div class="col-12 text-center mt-4">
                                            <button  class="btn btn-lg btn-block btn-primary lift text-uppercase" atl="signin">Submit</button>
                                        </div>
                                    </div>
                                    <div class="col-12 text-center mt-4">
                                        <span class="text-muted"><a href="<?php echo e(route('admin.login')); ?>" class="text-secondary">Back to Sign in</a></span>
                                    </div>


                                </form>
                                <!-- End Form -->

                            </div>
                        </div>


                </div>a
            </div>

        </div>

    </div>

    <!-- Jquery Core Js -->
    <script src="../assets/bundles/libscripts.bundle.js"></script>
</body>

<!-- Mirrored from pixelwibes.com/template/ebazar/html/dist/ui-elements/auth-signin.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 28 May 2024 08:48:59 GMT -->
</html>
<?php /**PATH C:\Users\HP\Desktop\doveway\secret\resources\views/backend/admin/auth/changepassword.blade.php ENDPATH**/ ?>