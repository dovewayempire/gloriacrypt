 <!-- JS
    ============================================ -->
    <script src="<?php echo e(asset('frontend/assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/vendor/modernizr-3.11.2.min.js')); ?>"></script>

    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('frontend/assets/js/plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/bootstrap.min.js')); ?>"></script>

    <!-- Plugins JS -->
    <script src="<?php echo e(asset('frontend/assets/js/plugins/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/aos.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/back-to-top.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/appear.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/plugins/jquery.magnific-popup.min.js')); ?>"></script>


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->




    <!-- Jquery Core Js -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
    <!-- JS

    ============================================ -->
    <script src="<?php echo e(asset('frontend/assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>

<?php echo $__env->yieldPushContent('child-scripts'); ?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- Include SweetAlert JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10/dist/sweetalert2.min.js"></script>
<!-- Include Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>


<?php /**PATH C:\Users\HP\Desktop\doveway\secret\resources\views/frontend/partials/main-script.blade.php ENDPATH**/ ?>