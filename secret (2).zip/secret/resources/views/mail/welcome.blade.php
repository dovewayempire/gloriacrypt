<!DOCTYPE html>
<html>
<head>
    <title>Welcome !!!</title>
</head>
<body>
    <h1>Welcome, </h1>
    <p>Thank you for joining </p>
    
    <p>Best Regards </p>

    <p>GloriaCrypt</p>
</body>
</html>
