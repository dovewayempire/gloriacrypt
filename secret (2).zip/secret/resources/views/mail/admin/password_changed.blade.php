<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Changed</title>
</head>
<body>
    <p>Hello,</p>
    <p>Your password has been successfully changed.</p>
    <p>Your new password is: <strong>{{ $newPassword }}</strong></p>
    <p>If you did not make this change, please contact us immediately.</p>
    <p>Thank you!</p>
</body>
</html
