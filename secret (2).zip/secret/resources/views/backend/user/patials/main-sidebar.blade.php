
<ul class="menu-list flex-grow-1 mt-3">
    <li><a class="m-link active" href="{{route('user.dashboard')}}"><i class="icofont-home fs-5"></i> <span>Dashboard</span></a>
    </li>
 <li>
    <a class="m-link active" href="{{route('user.support')}}"><i class="icofont-ui-v-card fs-5"></i> <span>Support</span></a>

 </li>
</ul>
