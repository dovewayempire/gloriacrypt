@extends('backend.user.master')
@section('content')
<div class="container-xxl">


    <div class="row g-2 pt-5 text-center">

        <div class="col-xl-12 text-center">
            <div class="align-items-center">
                <i class="icofont-email"></i>
                <span class="ms-2 text-center">adrianallan@gmail.com</span>
            </div>
        </div>
        <div class="col-xl-12 text-center">
            <div class=" align-items-center">
                <i class="icofont-birthday-cake"></i>
                <span class="ms-2">+447769767611</span>
            </div>
        </div>
        <div class="col-xl-12 text-center">
            <div class="align-items-center">
                <i class="icofont-address-book"></i>
                <span class="ms-2 ">2734  West Fork Street,EASTON 02334.</span>
            </div>
        </div>
    </div>





</div>
@endsection
