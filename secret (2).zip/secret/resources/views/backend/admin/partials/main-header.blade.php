<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>GloriaCrypt || Dashbaord</title>
    <link rel="icon" href="favicon.ico" type="image/x-icon"> <!-- Favicon-->

    <!-- plugin css file  -->
    <link rel="stylesheet" href="{{asset('backend/assets/plugin/datatables/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('backend/assets/plugin/datatables/dataTables.bootstrap5.min.css')}}">

    <!-- project css file  -->
    <link rel="stylesheet" href="{{asset('backend/assets/css/ebazar.style.min.css')}}">

    <style>
        .navbar-text{
            color: rgb(98, 137, 237);
        }

        .navbar-icon{
            color:rgb(98, 137, 237);

        }
        .icofont-bubble-right{
            color:rgb(98, 137, 237);
        }
        .icofont-home{
            color:rgb(98, 137, 237);
        }
        .icofont-ui-v-card{
            color:rgb(98, 137, 237);
        }
        span{
            color:rgb(98, 137, 237);
        }
    </style>
